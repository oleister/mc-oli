# Security Policy

## Reporting a Vulnerability

Please report any potential security issues to `team@nodered.org`. This will notify the core project team who will respond accordingly.
